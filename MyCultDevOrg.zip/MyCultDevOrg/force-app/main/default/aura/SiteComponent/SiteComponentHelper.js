({
	setupInitialValues : function(component, event, helper){
		var formFields = {
			'firstName' : '', 
			'lastName' : '',
			'email' : '',
			'communityUserType' : '',
			'password' : '',
			'confirmPassword' : '',
		}

		component.set('v.formFields', formFields);
	},

	checkFormValidation: function(component, event, helper){

		var formFields = component.get('v.formFields');
		var disableSubmitValue = false;

		//Check blank values
		if(formFields.firstName == '' || formFields.lastName == '' || formFields.email == '' || formFields.communityUserType == '' || formFields.passworde == '' || formFields.confirmPassword == ''){
			disableSubmitValue = true;
		}

		//Check email
		var regExpEmailformat = /^[A-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;
		var emailToLowerCase = formFields.email.toLowerCase();
		if( !emailToLowerCase.match(regExpEmailformat) ){
			disableSubmitValue = true;
		}

		//Check password requirements
		var regExpPasswordFormat = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
		if(formFields.password != '' && (formFields.password.length < 8 || !formFields.password.match(regExpPasswordFormat) )){
			console.log('password error: ', formFields.password);
			component.set('v.passwordError', true);
			disableSubmitValue = true;
		} else {
			component.set('v.passwordError', false);
		}

		//Check confirm password and password match
		if(formFields.confirmPassword != '' && (formFields.confirmPassword != formFields.password)){
			component.set('v.confirmPasswordError', true);
			disableSubmitValue = true;
		} else {
			component.set('v.confirmPasswordError', false);
		}

		component.set('v.disableSubmit', disableSubmitValue);
	},

	saveFieldInfo: function(component, event, helper){
		component.set('v.showErrorMessage', false);
		component.set('v.showSpinner', true);
		var formValues = component.get('v.formFields')

        var action = component.get("c.setFormValues");
        action.setParams({ formValues : JSON.stringify(formValues)});

        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
				let data = response.getReturnValue();
                // console.log("From server: ", data );
				if(data){
					component.set('v.showSpinner', false);
					component.set('v.showSuccessMessage', true);

					//We wait 3.5 seconds with the success message up and then reroute to the login page
					window.setTimeout(
						$A.getCallback(function() {
							helper.navigateToLoginPage(component, event, helper);
						}), 3500
					);
				}
            }
            else if (state === "INCOMPLETE") {
            	component.set('v.showErrorMessage', true);
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }

				component.set('v.showErrorMessage', true);
            }
			component.set('v.showSpinner', false);
        });

        $A.enqueueAction(action);
     
	},

	navigateToLoginPage : function(component, event, helper){

		var urlEvent = $A.get("e.force:navigateToURL");

		//For the url, we just need to remove everything after the "login".  
		//We can't send in a null value or else it won't redirect, sending in a "/" 
		//takes it back to the root directory (in this case, it is "login")
	    urlEvent.setParams({
	      "url": '/',
	      "isRedirect": true
	    });
    	urlEvent.fire();
			
	},
})