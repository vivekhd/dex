({
	doInit : function(component, event, helper) {
		helper.setupInitialValues(component, event, helper);
	},

	checkFormValidation : function(component, event, helper){
		helper.checkFormValidation(component, event, helper);
	},

	handleSubmitClick : function(component, event, helper){
		helper.saveFieldInfo(component, event, helper);
	},

	navigateToLoginPage : function(component, event, helper){
		helper.navigateToLoginPage(component, event, helper);
	}
})