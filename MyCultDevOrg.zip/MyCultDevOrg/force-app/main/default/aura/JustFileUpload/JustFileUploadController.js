({
	handleUploadFinished : function(cmp, event, helper) {
    	console.log('file upload complete now make the status updates');
        var uploadedFiles = event.getParam('files');
        console.log('doc id == ' + uploadedFiles[0].documentId);
        
    }
})