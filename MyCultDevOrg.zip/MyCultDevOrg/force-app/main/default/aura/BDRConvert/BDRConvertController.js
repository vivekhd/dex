({
	bdrConvert : function(cmp, event, helper) {
		var evt = $A.get("e.force:navigateToComponent");
        console.log('Event '+evt);
   
        evt.setParams({
            componentDef  : "c:OpportunityRecordType",
            componentAttributes : {
                contactId: cmp.get("v.recordId")
            }
        });
        evt.fire();
	}
})