({
   getPageLayoutFields : function (component, event, helper)
    {
        var action = component.get("c.getPageLayoutFields");
        action.setParams({ "contactId" : component.get("v.contactId"), "rtName" : component.get("v.RecordTypeName")});
		action.setCallback(this, function(response) {
        	var state = response.getState();
			if (state === "SUCCESS") {
                component.set("v.layoutSections", response.getReturnValue() );
            }
            else if (state === "INCOMPLETE") {
            }
            else if (state === "ERROR") {
                var errors = response.getError();
            }
            
            helper.getRecordTypeIdByName(component, event, helper);
        });
        
        $A.enqueueAction(action);
    },
   
   
    getRecordTypeIdByName : function(component, event, helper ) {
        
        var action = component.get("c.getRecordTypeIdByName");
        action.setParams({"rtName" : component.get("v.RecordTypeName")});
		action.setCallback(this, function(response) {
        	var state = response.getState();
			if (state === "SUCCESS") {
                component.set("v.RecordTypeId", response.getReturnValue() );
            }
            else if (state === "INCOMPLETE") {
            }
            else if (state === "ERROR") {
                var errors = response.getError();
				console.log( errors );
            }
            
        });
        
        $A.enqueueAction(action);
    },
    
    handleSuccess : function(component, event, helper ) {
        
        //Redirect to detail page on success
	    var payload = event.getParams().response;
        var navService = component.find("navService");
    
        var pageReference = {
            type: 'standard__recordPage',
            attributes: {
                "recordId": payload.id,
                "objectApiName": component.get("v.sObjectName"),
                "actionName": "view"
            }
        }
        event.preventDefault();
        navService.navigate(pageReference);
    },
    
    handleShowToast : function(component, event, helper ) {
        var resultsToast = $A.get("e.force:showToast");
        resultsToast.setParams({
            "type" : "success",	
            "title": "Success",
            "key" : "success",
            "message": "Opportunity was created."
        });
        resultsToast.fire();  
    },
    handlePostDML : function(component, event, helper )
    {
        var payload = event.getParams().response;
        console.log('payload.Id -->'+payload.id);
        var action = component.get("c.contactConvert");
        action.setParams({ "contactId" : component.get("v.contactId"), "opportunityId" : payload.id});
		action.setCallback(this, function(response) {
        	var state = response.getState();
			if (state === "SUCCESS") {
                helper.handleShowToast(component, event, helper);
            }
            else if (state === "INCOMPLETE") {
            }
            else if (state === "ERROR") {
                
            }
            
        });
        
        $A.enqueueAction(action);
    },   
    
})