({
    doInit: function( component, event, helper ) { 
       console.log('Inside component');
        helper.getPageLayoutFields(component, event, helper);
    },
    /*handleOpportunitySave : function(component, event, helper) {
        
        
        console.log('Hello');
        event.preventDefault(); // stop form submission
  		var eventFields = event.getParam("fields");
        //fields.AccountId = cmp.get("v.recordId");
        //component.find('opportunityRecordCreator').submit();
        console.log('fields --> '+eventFields);
        console.log(component.get('opportunityRecordCreator'));
    },*/

    handleSuccess : function(component, event, helper) {
        
      helper.handleSuccess(component, event, helper); 
	  //helper.handleShowToast(component, event, helper);
      helper.handlePostDML(component, event, helper);
        
    },
    handleLoad : function(component, event, helper) {
    	component.set("v.showSpinner", false);   
    },
    handleError: function(component, event, helper) {
		
    },
    handleRecordSave : function(component, event, helper) {
        
      //event.preventDefault(); // stop form submission
      //var fields = event.getParam('fields');
      console.log('----------RecordSave');
	  //console.log('fields-'+fields);
      //console.log('fields-'+fields.BDR_Convert__c);

     // console.log('fields'+ fields);
    // eventFields["BDR_Convert__c"] = True;
     //eventFields["Name"] = "Hello Opportunity";
     //component.find("opportunityRecordCreator").submit();

        
        
    },
	 handleSubmit : function(component, event, helper) {
       //We don't need to put basic validation here as that are handle by lightning:inputfield and recordEditForm
       //event.preventDefault(); //use this to stop default flow
       //console.log('fields: '+JSON.stringify(event.getParam('fields')));
        //console.log(fields);        
       //component.find("opportunityRecordCreator").submit();
       //
       event.preventDefault(); // stop form submission
      var fields = event.getParam('fields');
      console.log('----------2');
	  console.log('fields-'+fields);
      //console.log('fields-'+fields.BDR_Convert__c);

      console.log('fields'+ fields);
     //eventFields["BDR_Convert__c"] = True;
     //eventFields["Name"] = "Hello Opportunity";
     //component.find("opportunityRecordCreator").submit();
  
    },
    handleCancel : function(component, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        console.log('Event '+evt);
        evt.setParams({
            componentDef  : "c:OpportunityRecordType",
            componentAttributes : {
                contactId: component.get("v.contactId"),
                recordTypeValue: component.get("v.RecordTypeName")                
            }
          });
        
        evt.fire();
    }
})