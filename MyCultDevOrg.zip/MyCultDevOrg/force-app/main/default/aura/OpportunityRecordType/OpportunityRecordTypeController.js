({
	
   handleCancel : function (cmp, event, helper) {
      var navEvt = $A.get("e.force:navigateToSObject");
      var contactRecordId = cmp.get("v.recordId");
      navEvt.setParams({
      "recordId": cmp.get("v.contactId"),
      "slideDevName": "detail"
    });
    navEvt.fire();
   },
    handleSelect : function (cmp, event, helper) {
        var evt = $A.get("e.force:navigateToComponent");
        //var contactRecordId = cmp.get("v.recordId");
        //var recordType = cmp.get("v.recordTypeValue");
        evt.setParams({
            componentDef  : "c:OpportunityConvert" ,
            componentAttributes : {
                contactId: cmp.get("v.contactId"),
                RecordTypeName: cmp.get("v.recordTypeValue")
                
            }
        

        });
      
        evt.fire();
    }
})