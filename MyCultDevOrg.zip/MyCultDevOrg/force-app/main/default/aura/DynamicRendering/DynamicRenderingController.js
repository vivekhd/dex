({
    doInit: function( component, event, helper ) { 
       console.log('Inside component');
        helper.getPageLayoutFields(component, event, helper);
    },
    handleSubmit : function(cmp, event, helper) {
      event.preventDefault();       // stop the form from submitting
            var fields = event.getParam('fields');
        	console.log('----------');
        	console.log('fields-'+fields);
        console.log('fields-'+fields.Industry);
            fields.Industry = '32 Prince Street';
        	console.log('fields1-'+fields.Industry);
          // component.find('form').submit(fields);
},
    submitFunction : function(component, event, helper) {
        
        var f = component.getElement()
        console.log(f.innerHTML)
        /*.querySelector('accountRecordCreator');
        debugger;
        var e = new Event('submit', {
            'bubbles'    : true, 
            'cancelable' : true
        });
        f.dispatchEvent(e);*/
 
        /*
      //e.preventDefault();       // stop the form from submitting
            var fields = e.getParam('fields');
        	console.log('----------');
        	console.log('fields-'+fields);
        console.log('fields-'+fields.Industry);
            fields.Industry = '32 Prince Street';
        	console.log('fields1-'+fields.Industry);
          // component.find('form').submit(fields);*/
           
},
    handleLoad : function(component, event, helper) {
    	component.set("v.showSpinner", false);   
    }
})