({
	getPageLayoutFields : function (component, event, helper)
    {
        var action = component.get("c.getPageLayoutFields");
        //action.setParams({ "contactId" : component.get("v.contactId"), "rtName" : component.get("v.RecordTypeName")});
		action.setCallback(this, function(response) {
        	var state = response.getState();
			if (state === "SUCCESS") {
                component.set("v.layoutSections", response.getReturnValue() );
            }
            else if (state === "INCOMPLETE") {
            }
            else if (state === "ERROR") {
                var errors = response.getError();
            }
            
            
        });
        
        $A.enqueueAction(action);
    }
})