import { LightningElement, api, wire, track } from 'lwc';
import close_chat from '@salesforce/resourceUrl/close_chat';
import chatIcon from '@salesforce/resourceUrl/open_chat';
import minimize_icon from '@salesforce/resourceUrl/minimize_icon'
//import getDomainName from '@salesforce/apex/customChatBotClass.getDomainName';
 /* eslint-disable no-console */
 /* eslint-disable no-alert */

export default class CustomChatBot extends LightningElement {
    @track displayCondition = false;
    // myImage = cardImage;
    chatOpen = chatIcon;
    minimize_chat = minimize_icon;
    closeChat = close_chat;
    @track login_url;
   // @wire (getDomainName) communityDomainname;

    openDesk(){
        console.log('opening desk');
        // this.login_url = "https://krishnadextara-dev-ed.lightning.force.com/lightning/page/home";
        this.login_url = "/OfflineBot/s/login/";
        //this.login_url= this.communityDomainname.data +'/login';
        this.displayCondition = true;
    }

    closeDesk(){
        this.displayCondition = false;
    }

}