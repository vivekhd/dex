declare module "@salesforce/resourceUrl/Image" {
    var Image: string;
    export default Image;
}
declare module "@salesforce/resourceUrl/JquerySelfService" {
    var JquerySelfService: string;
    export default JquerySelfService;
}
declare module "@salesforce/resourceUrl/PostDeploymentGuide" {
    var PostDeploymentGuide: string;
    export default PostDeploymentGuide;
}
declare module "@salesforce/resourceUrl/SelfServiceGuide" {
    var SelfServiceGuide: string;
    export default SelfServiceGuide;
}
declare module "@salesforce/resourceUrl/SiteSamples" {
    var SiteSamples: string;
    export default SiteSamples;
}
